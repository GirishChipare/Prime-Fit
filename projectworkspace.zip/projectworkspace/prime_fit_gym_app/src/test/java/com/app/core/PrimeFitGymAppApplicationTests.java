package com.app.core;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimeFitGymAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
