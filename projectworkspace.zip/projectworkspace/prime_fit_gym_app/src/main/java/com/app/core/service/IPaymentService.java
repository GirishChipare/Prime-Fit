package com.app.core.service;

public interface IPaymentService {

}
