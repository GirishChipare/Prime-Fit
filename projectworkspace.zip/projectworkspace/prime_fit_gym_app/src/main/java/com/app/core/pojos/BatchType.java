package com.app.core.pojos;

public enum BatchType {
	YOGA, ZUMBA, AEROBICS, CROSSFIT, WEIGHT_TRAINING
}
