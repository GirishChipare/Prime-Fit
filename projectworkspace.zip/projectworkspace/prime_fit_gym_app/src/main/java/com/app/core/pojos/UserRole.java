package com.app.core.pojos;

public enum UserRole {
	SUPER_ADMIN, LOCAL_ADMIN, TRAINER, MEMBER
}
