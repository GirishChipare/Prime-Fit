//import { url } from "../../common/constant";
//import { LoginAction } from "../actions/LoginAction";
import { useHistory } from "react-router-dom";
import { useState } from "react";
import { Link } from "react-router-dom";
import Swal from "sweetalert2";
import React from "react";
import Navbar from "../../components/Navbar";
import axios from "axios";
import { url } from "../../common/constant";
 import { useDispatch } from "react-redux";
import { LoginAction } from "../../actions/LoginAction";



const SignIn = () => {

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const history = useHistory()  //to redirect to another component
  const dispatch = useDispatch()  //to dispatch the action

const UserLogin = () => { 
  if (email.length === 0) {
    alert('please enter email')
  } else if (password.length === 0) {
    alert('please enter password')
  } else {
    let data = {
      email:email,
      password:password
     };
    console.log(data);
    //send user info to the API
    axios.post(url+"/users/signin", data).then((response) => {
      const result = response.data;
      dispatch(LoginAction(result.response));
      if (result.status === "OK" && result.role === "SUPER_ADMIN") {
        
        Swal.fire({
          icon: 'success',
          title: 'LoginAs '+email+' Successfully',
          showConfirmButton: false,
          timer: 1500
        })
        history.push('/adminpage')
       // alert("LoginAs "+email+" Successfully")
        
      } 
      
      else if (result.status === "OK" && result.role === "LOCAL_ADMIN") {
        Swal.fire({
          icon: 'success',
          title: 'LoginAs '+email+' Successfully',
          showConfirmButton: false,
          timer: 1500
        })
        history.push('/localadminpage')
      }

      else if (result.status === "OK" && result.role === "TRAINER") {
        Swal.fire({
          icon: 'success',
          title: 'LoginAs '+email+' Successfully',
          showConfirmButton: false,
          timer: 1500
        })
        history.push('/trainerpage')
      }

      else if (result.status === "OK" && result.role === "MEMBER") {
        Swal.fire({
          icon: 'success',
          title: 'LoginAs '+email+' Successfully',
          showConfirmButton: false,
          timer: 1500
        })
        history.push('/memberpage')
      }

      else {
        console.log(result.message);
        alert("User not found...plz try again!!");
      }
    });
  }
}

  return (
    <div className="privacydiv">
       <Navbar/> 
       <hr/><hr/><hr/><hr/><hr/><hr/><hr/><hr/><hr/><hr/><hr/>
        <div class="form-group row">
          <label for="email5" class="col-sm-4 col-form-label" align="right">
            Email
          </label>
          
          <div class="col-sm-4">
            <input

              type="email"
              class="form-control"
              placeholder="Email"
              onChange={(event) => {setEmail(event.target.value)}}
            />
          </div>
         
        </div>
        <hr/><hr/><hr/><hr/><hr/>
        <div class="form-group row">
          <label for="password5" class="col-sm-4 col-form-label" align="right">
            Password
          </label>
          <div class="col-sm-4">
            <input
             
              type="password"
              class="form-control"
              placeholder="Password"
              onChange={(event) => {setPassword(event.target.value)}}
            />
          </div>
        </div>
        <hr/><hr/><hr/><hr/><hr/>
        <div >
          <div class="col-sm-16 text-center">
            <button  type="button" class="btn btn-primary" onClick={UserLogin}>
              Sign in 
            </button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            {/* <Link to="/register" className="btn btn-warning"> SignUp </Link> */}
          </div>
        </div>
      
    </div>
  );
};

export default SignIn;
